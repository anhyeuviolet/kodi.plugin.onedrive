#-------------------------------------------------------------------------------
# Copyright (C) 2017 Carlos Guzman (cguZZman) carlosguzmang@protonmail.com
# 
# This file is part of OneDrive for Kodi
# 
# OneDrive for Kodi is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# 
# Cloud Drive Common Module for Kodi is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#-------------------------------------------------------------------------------

from resources.lib.startup_refresh import StartupRefreshService
from resources.lib.stream_service import StreamingDownloadService
from resources.lib.source_service import RelayingSourceService
from resources.lib.vendor.clouddrive_common.service.utils import ServiceUtil
from resources.lib.provider.onedrive import OneDrive
from resources.lib.export_service import PlaybackAwareExportService
from resources.lib.vendor.clouddrive_common.service.player import PlayerService


# The four listeners, and one keepalive.
#
# The keepalive is last for the same reason it is here at all. `ServiceUtil.run`
# starts each of these once, in its own daemon thread, and then waits for the
# shutdown; it has no periodic set, so a service whose `start` returns has run
# exactly once at Kodi start -- which is what a keepalive wants and what a
# refresh on every poll would ruin, since every write is a chance to leave a
# temporary file behind on a device that is power-cut rather than shut down.
# Last in the list means the four servers have claimed their ports before the
# token exchange begins, and running inside the runner rather than before it
# means the exchange delays none of them.
#
# The download listener relays the file itself rather than redirecting to
# OneDrive's short-lived download URL, so playback does not stop when that URL
# expires; resources/lib/streaming.py has the reasoning. The export listener
# waits while a video plays, so its first pass after Kodi starts -- change
# lookups, .strm writes, a library scan -- does not compete with the first
# video of the session; resources/lib/export_service.py. The source listener
# hands files to that relay too, and starts as soon as its setting is turned
# on; resources/lib/source_service.py. The player listener is untouched. The
# source listener stays off until the user turns it on, because it serves an
# index of the drive to any program on the box (VENDORED.md).
if __name__ == '__main__':
    ServiceUtil.run([StreamingDownloadService(OneDrive), RelayingSourceService(OneDrive),
                     PlaybackAwareExportService(OneDrive), PlayerService(OneDrive),
                     StartupRefreshService(OneDrive)])